/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import { Note } from "../types";
import { parseMarkdownToHtml } from "../utils";
import {
  Heading1,
  Bold,
  Italic,
  Code,
  Link2,
  Quote,
  Eye,
  Edit3,
  Columns,
  Clock,
  ChevronRight,
  FileText,
} from "lucide-react";

interface EditorProps {
  note: Note;
  notes: Note[];
  onUpdateNote: (id: string, updates: Partial<Note>) => void;
  onSelectNote: (id: string) => void;
  onWikilinkClick: (title: string) => void;
}

type Workmode = "edit" | "preview" | "split";

export default function Editor({
  note,
  notes,
  onUpdateNote,
  onSelectNote,
  onWikilinkClick,
}: EditorProps) {
  const [mode, setMode] = useState<Workmode>("split");
  const [htmlContent, setHtmlContent] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Parse markdown asynchronously when note content changes
  useEffect(() => {
    let active = true;
    const render = async () => {
      const html = await parseMarkdownToHtml(note.content || "");
      if (active) {
        setHtmlContent(html);
      }
    };
    render();
    return () => {
      active = false;
    };
  }, [note.content]);

  // Insert markdown helper buttons
  const insertMarkdown = (before: string, after: string = "") => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;

    const selectedText = text.substring(start, end);
    const replacement = before + selectedText + after;

    const newContent = text.substring(0, start) + replacement + text.substring(end);
    onUpdateNote(note.id, { content: newContent });

    // Reset cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(
        start + before.length,
        start + before.length + selectedText.length
      );
    }, 50);
  };

  // Find backlink notes (notes that link to this current note by its exact title)
  const backlinks = notes.filter((n) => {
    if (n.id === note.id) return false;
    const wikilinkPattern = new RegExp(`\\[\\[\\s*${escapeRegExp(note.title)}\\s*(?:\\|.*?)?\\]\\]`, "i");
    return wikilinkPattern.test(n.content);
  });

  function escapeRegExp(str: string) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // Intercept click events in preview container to handle dynamic wikilinks
  const handlePreviewClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    const wikilinkEl = target.closest("[data-note]");
    if (wikilinkEl) {
      const noteTitleEncoded = wikilinkEl.getAttribute("data-note");
      if (noteTitleEncoded) {
        const noteTitle = decodeURIComponent(noteTitleEncoded);
        onWikilinkClick(noteTitle);
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden h-full bg-slate-50 dark:bg-zinc-950">
      
      {/* Workspace Toolbar */}
      <div className="bg-white dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 px-4 py-2 flex items-center justify-between shrink-0 shadow-sm">
        
        {/* Editor controls / formatting helpers */}
        <div className="flex items-center space-x-1.5 overflow-x-auto py-1">
          <button
            onClick={() => insertMarkdown("## ")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title="Heading"
          >
            <Heading1 className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertMarkdown("**", "**")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title="Bold text"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertMarkdown("*", "*")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title="Italic text"
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertMarkdown("> ")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title="Blockquote"
          >
            <Quote className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertMarkdown("`", "`")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title="Inline code"
          >
            <Code className="w-4 h-4" />
          </button>
          <div className="h-4 w-px bg-slate-200 dark:bg-zinc-700 mx-1" />
          <button
            onClick={() => insertMarkdown("[[", "]]")}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded text-indigo-600 dark:text-indigo-400 transition-colors cursor-pointer flex items-center space-x-1 font-mono text-xs font-semibold"
            title="Insert Wikilink to another note"
          >
            <Link2 className="w-4 h-4" />
            <span>[[]]</span>
          </button>
        </div>

        {/* View Mode Selectors */}
        <div className="flex items-center space-x-1 border border-slate-200 dark:border-zinc-700 p-0.5 rounded-lg bg-slate-50 dark:bg-zinc-800">
          <button
            onClick={() => setMode("edit")}
            className={`p-1.5 rounded-md flex items-center space-x-1 text-xs font-semibold transition-all cursor-pointer ${
              mode === "edit"
                ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white"
            }`}
            title="Markdown Source Editor"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Source</span>
          </button>
          <button
            onClick={() => setMode("preview")}
            className={`p-1.5 rounded-md flex items-center space-x-1 text-xs font-semibold transition-all cursor-pointer ${
              mode === "preview"
                ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white"
            }`}
            title="Formatted Preview"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Preview</span>
          </button>
          <button
            onClick={() => setMode("split")}
            className={`p-1.5 rounded-md flex items-center space-x-1 text-xs font-semibold transition-all cursor-pointer ${
              mode === "split"
                ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white"
            }`}
            title="Side-by-side split screen"
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Split</span>
          </button>
        </div>
      </div>

      {/* Editor Content Canvas */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* EDIT PANE */}
        {(mode === "edit" || mode === "split") && (
          <div className="flex-1 flex flex-col p-4 sm:p-6 overflow-hidden border-r border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900">
            {/* Note Title Input */}
            <input
              type="text"
              value={note.title}
              onChange={(e) => onUpdateNote(note.id, { title: e.target.value })}
              placeholder="Note Title"
              className="w-full bg-transparent text-2xl font-bold border-none outline-none focus:ring-0 mb-4 text-slate-900 dark:text-white placeholder-slate-300 dark:placeholder-zinc-700"
            />
            
            {/* Note content textarea */}
            <textarea
              ref={textareaRef}
              value={note.content}
              onChange={(e) => onUpdateNote(note.id, { content: e.target.value })}
              placeholder="Start writing... Type [[Other Note]] to create/link notes."
              className="flex-1 w-full bg-transparent border-none outline-none resize-none focus:ring-0 font-mono text-sm leading-relaxed overflow-y-auto text-slate-800 dark:text-zinc-200 placeholder-slate-300 dark:placeholder-zinc-700"
            />
          </div>
        )}

        {/* PREVIEW PANE */}
        {(mode === "preview" || mode === "split") && (
          <div className="flex-1 flex flex-col p-4 sm:p-6 overflow-y-auto bg-slate-50 dark:bg-zinc-950/20">
            {/* Preview Title */}
            <h2 className="text-3xl font-bold mb-6 text-slate-950 dark:text-white pb-2 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
              <span>{note.title || "Untitled Note"}</span>
              <div className="flex items-center space-x-1 text-xs text-slate-400 dark:text-zinc-500 font-normal">
                <Clock className="w-3.5 h-3.5" />
                <span>Updated {new Date(note.updatedAt).toLocaleTimeString()}</span>
              </div>
            </h2>

            {/* Markdown rendered output with custom event interceptor */}
            <div
              onClick={handlePreviewClick}
              className="markdown-body text-slate-800 dark:text-zinc-200 flex-1 prose dark:prose-invert max-w-none pb-12"
              dangerouslySetInnerHTML={{ __html: htmlContent }}
            />

            {/* BACKLINKS SECTION */}
            <div className="mt-12 pt-6 border-t border-slate-200 dark:border-zinc-800 shrink-0">
              <h3 className="text-xs font-bold text-slate-400 dark:text-zinc-500 uppercase tracking-wider mb-3 flex items-center space-x-1.5">
                <ChevronRight className="w-3.5 h-3.5" />
                <span>Backlinks ({backlinks.length})</span>
              </h3>
              
              {backlinks.length === 0 ? (
                <p className="text-xs text-slate-400 dark:text-zinc-500 italic">No notes reference this note yet. Use [[{note.title}]] inside another note to link them.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {backlinks.map((linkNote) => (
                    <button
                      key={linkNote.id}
                      onClick={() => onSelectNote(linkNote.id)}
                      className="flex items-center space-x-2 text-xs text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/15 p-2 rounded-lg border border-slate-100 dark:border-zinc-800 bg-white dark:bg-zinc-900 transition-colors text-left w-full cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5 shrink-0" />
                      <span className="font-semibold truncate">{linkNote.title}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
