/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Note } from "../types";
import { Search, Plus, Trash2, BookOpen, Download, Sun, Moon } from "lucide-react";

interface SidebarProps {
  notes: Note[];
  currentNoteId: string;
  onSelectNote: (id: string) => void;
  onCreateNote: (title?: string) => void;
  onDeleteNote: (id: string) => void;
  onExportHtml: () => void;
  darkMode: boolean;
  onToggleTheme: () => void;
}

export default function Sidebar({
  notes,
  currentNoteId,
  onSelectNote,
  onCreateNote,
  onDeleteNote,
  onExportHtml,
  darkMode,
  onToggleTheme,
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <aside className="w-64 bg-slate-50 dark:bg-zinc-950 border-r border-slate-200 dark:border-zinc-800 flex flex-col shrink-0 h-full">
      {/* Sidebar Header Brand */}
      <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50 dark:bg-zinc-950 select-none">
        <div className="flex items-center space-x-2">
          <div className="bg-indigo-600 p-1.5 rounded text-white flex items-center justify-center">
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-xs font-bold text-slate-800 dark:text-zinc-200 uppercase tracking-widest">Lite Obsidian</h1>
            <p className="text-[10px] text-slate-400 dark:text-zinc-500 font-mono uppercase tracking-wider">Local Vault</p>
          </div>
        </div>

        {/* Theme Toggle Button */}
        <button
          onClick={onToggleTheme}
          className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-200 dark:hover:bg-zinc-800 rounded transition-colors cursor-pointer"
          title={darkMode ? "Switch to light theme" : "Switch to dark theme"}
        >
          {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>

      {/* Search Input Box */}
      <div className="p-4 border-b border-slate-200 dark:border-zinc-800/80 space-y-3">
        <div className="relative">
          <input
            type="text"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded px-3 py-1.5 pl-8 text-xs placeholder-slate-400 dark:placeholder-zinc-500 focus:outline-none focus:border-indigo-500 text-slate-800 dark:text-zinc-100 transition-colors"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>

        {/* New Note Button */}
        <button
          onClick={() => onCreateNote()}
          className="w-full flex items-center justify-center space-x-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded text-xs font-medium transition-all shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Note</span>
        </button>
      </div>

      {/* Notes List Scroll Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1">
        <div className="text-[10px] font-bold text-slate-400 dark:text-zinc-500 uppercase tracking-wider mb-2 px-1">Vault Notes</div>
        {filteredNotes.length === 0 ? (
          <div className="p-4 text-center text-xs text-slate-400 dark:text-zinc-500 italic">
            No notes found
          </div>
        ) : (
          filteredNotes.map((note) => {
            const isActive = note.id === currentNoteId;
            return (
              <div
                key={note.id}
                onClick={() => onSelectNote(note.id)}
                className={`flex items-center justify-between px-2 py-1.5 rounded text-xs cursor-pointer group transition-all duration-150 ${
                  isActive
                    ? "bg-slate-200 dark:bg-zinc-800 text-slate-900 dark:text-white font-medium"
                    : "hover:bg-slate-100 dark:hover:bg-zinc-800/40 text-slate-600 dark:text-zinc-400"
                }`}
              >
                <span className="truncate flex-1 pr-2">{note.title || "Untitled Note"}</span>
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteNote(note.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-500 rounded transition-all cursor-pointer"
                  title="Delete note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Export Footer Panel */}
      <div className="p-4 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950">
        <button
          onClick={onExportHtml}
          className="w-full flex items-center justify-center space-x-2 border border-slate-200 dark:border-zinc-800 hover:border-indigo-500 dark:hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 text-slate-700 dark:text-zinc-300 hover:text-indigo-600 dark:hover:text-indigo-400 py-2 px-3 rounded text-xs font-semibold tracking-wider uppercase transition-all duration-150 cursor-pointer shadow-sm bg-white dark:bg-zinc-900"
          title="Save as single HTML with embedded notes, compatible with .hta"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export HTA / HTML</span>
        </button>
      </div>
    </aside>
  );
}
