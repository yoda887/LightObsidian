/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface GraphNode {
  id: string;
  title: string;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
  isCurrent: boolean;
}

export interface GraphLink {
  source: string; // note id
  target: string; // note id
}
