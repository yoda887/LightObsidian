/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react";
import { Note } from "./types";
import { generateSingleHtmlApp } from "./utils";
import Sidebar from "./components/Sidebar";
import Editor from "./components/Editor";
import GraphView from "./components/GraphView";
import { Map, FileText, Settings, Download, BookOpen } from "lucide-react";

// Default placeholder notes to guide the user
const DEFAULT_NOTES: Note[] = [
  {
    id: "welcome",
    title: "Welcome Note",
    content: `# Welcome to Lite Obsidian!

This is a beautiful, highly responsive, and lightweight analog of **Obsidian** built to organize your thoughts, knowledge, and notes.

## 🚀 Key Features
1. **Markdown Editing**: Full support for styled headers, code blocks, lists, and quotes.
2. **Wikilinks \`[[Link]]\`**: Link notes instantly. Type \`[[Obsidian HTA Concept]]\` to see a connection in action!
3. **Graph View (Map)**: A force-directed visual canvas representation of all notes and connections.
4. **Standalone Exporter**: Build and export the entire workspace with your current notes as a **single, fully-functional HTML / HTA file**.

## 🔗 Try out Wikilinks
Click this link to explore how HTA apps run: [[Obsidian HTA Concept]] or start brainstorming with [[Mindmap & Brainstorming]].
If you click a link pointing to a note that doesn't exist yet (like [[My Personal Log]]), the engine will automatically offer to create it for you!

## 🗺️ Interactive Graph
Click on the **Graph Map** tab in the main workspace header to see these notes animate, attract each other, and hover/click to explore!`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "hta-concept",
    title: "Obsidian HTA Concept",
    content: `# Obsidian HTML & HTA Concept

The user requested a single self-contained HTML file that can be converted into a Windows **.hta** (HTML Application).

## 💡 What is an HTA file?
An **HTA** is a Windows file extension for HTML pages that run with system-level access outside the browser sandbox. 
- You can simply rename the exported file from \`obsidian_vault.html\` to \`obsidian_vault.hta\`.
- Double-clicking it on Windows opens it in a standalone window, looking and acting like a native desktop application!

## 💾 Saving Notes Inside HTML/HTA
When you edit notes inside the exported file:
- It automatically persists changes inside your browser's \`localStorage\` so your work is safe across opens!
- It contains its own **Export HTA/HTML** button inside. This means you can download a *new* updated standalone file containing your latest changes baked right into the source code!

*Return to the [[Welcome Note]] or see [[Mindmap & Brainstorming]].*`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "brainstorm",
    title: "Mindmap & Brainstorming",
    content: `# Mindmap & Brainstorming

Use Lite Obsidian to brainstorm interconnected projects. By linking concepts together, you build a "second brain" visual network.

## 📝 Connected Projects
- **[[My Projects]]**: Tracking active development cycles.
- **[[Daily Habits]]**: Mindful productivity checklist.

As you create links, check the **Graph Map** panel to watch the nodes form a neural-like database map of your knowledge.

---
*Created during your session. Link back to [[Welcome Note]].*`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "my-projects",
    title: "My Projects",
    content: `# My Projects

Here you can organize active tasks and goals.

## 🛠️ Lite Obsidian Sandbox
- [x] Integrate force-directed physics canvas for note relations.
- [x] Configure self-contained single-file HTML exporter template.
- [ ] Write my first note from scratch!

*Related notes:*
- Check [[Welcome Note]]
- Or read about [[Obsidian HTA Concept]]`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export default function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [currentNoteId, setCurrentNoteId] = useState<string>("");
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [workspaceTab, setWorkspaceTab] = useState<"editor" | "graph">("editor");

  // Load notes and theme on initial load
  useEffect(() => {
    const storedNotes = localStorage.getItem("lite_obsidian_react_notes");
    if (storedNotes) {
      try {
        const parsed = JSON.parse(storedNotes);
        setNotes(parsed);
        if (parsed.length > 0) {
          setCurrentNoteId(parsed[0].id);
        }
      } catch (e) {
        setNotes(DEFAULT_NOTES);
        if (DEFAULT_NOTES.length > 0) {
          setCurrentNoteId(DEFAULT_NOTES[0].id);
        }
      }
    } else {
      setNotes(DEFAULT_NOTES);
      if (DEFAULT_NOTES.length > 0) {
        setCurrentNoteId(DEFAULT_NOTES[0].id);
      }
    }

    // Load theme
    const savedTheme = localStorage.getItem("lite_obsidian_theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
      setDarkMode(true);
      document.documentElement.classList.add("dark");
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove("dark");
    }
  }, []);

  // Save notes to localStorage whenever they change
  const saveNotes = (updatedNotes: Note[]) => {
    setNotes(updatedNotes);
    localStorage.setItem("lite_obsidian_react_notes", JSON.stringify(updatedNotes));
  };

  // Toggle theme
  const handleToggleTheme = () => {
    const newVal = !darkMode;
    setDarkMode(newVal);
    if (newVal) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("lite_obsidian_theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("lite_obsidian_theme", "light");
    }
  };

  // Select note
  const handleSelectNote = (id: string) => {
    setCurrentNoteId(id);
    setWorkspaceTab("editor"); // switch back to editor to view note details immediately
  };

  // Create a new note
  const handleCreateNote = (title?: string) => {
    const finalTitle = title?.trim() || generateUniqueTitle();
    
    // Check if a note with this title already exists
    const existing = notes.find(n => n.title.trim().toLowerCase() === finalTitle.toLowerCase());
    if (existing) {
      setCurrentNoteId(existing.id);
      setWorkspaceTab("editor");
      return;
    }

    const newNote: Note = {
      id: "note_" + Date.now(),
      title: finalTitle,
      content: `# ${finalTitle}\n\nStart typing here...`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = [...notes, newNote];
    saveNotes(updated);
    setCurrentNoteId(newNote.id);
    setWorkspaceTab("editor");
  };

  const generateUniqueTitle = (): string => {
    let index = 1;
    let title = `Untitled ${index}`;
    while (notes.some(n => n.title.toLowerCase() === title.toLowerCase())) {
      index++;
      title = `Untitled ${index}`;
    }
    return title;
  };

  // Delete note
  const handleDeleteNote = (id: string) => {
    if (confirm("Are you sure you want to delete this note?")) {
      const filtered = notes.filter(n => n.id !== id);
      saveNotes(filtered);
      
      if (currentNoteId === id) {
        if (filtered.length > 0) {
          setCurrentNoteId(filtered[0].id);
        } else {
          setCurrentNoteId("");
        }
      }
    }
  };

  // Update note content or title
  const handleUpdateNote = (id: string, updates: Partial<Note>) => {
    const updated = notes.map(note => {
      if (note.id === id) {
        return {
          ...note,
          ...updates,
          updatedAt: new Date().toISOString()
        };
      }
      return note;
    });
    saveNotes(updated);
  };

  // Handle clicking wikilinks inside formatted Preview
  const handleWikilinkClick = (noteTitle: string) => {
    const found = notes.find(n => n.title.trim().toLowerCase() === noteTitle.trim().toLowerCase());
    if (found) {
      setCurrentNoteId(found.id);
    } else {
      // Suggest creation of note with that title
      const userConfirmed = confirm(`Note "${noteTitle}" does not exist. Would you like to create it?`);
      if (userConfirmed) {
        handleCreateNote(noteTitle);
      }
    }
  };

  // Export current list of notes as a single HTA/HTML file
  const handleExportHtml = () => {
    const singleHtmlContent = generateSingleHtmlApp(notes);
    const blob = new Blob([singleHtmlContent], { type: "text/html" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "obsidian_standalone.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const currentNote = notes.find(n => n.id === currentNoteId);
  const wordCount = currentNote ? (currentNote.content || "").trim().split(/\s+/).filter(Boolean).length : 0;
  const charCount = currentNote ? (currentNote.content || "").length : 0;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-white dark:bg-zinc-950 text-slate-800 dark:text-zinc-200 transition-colors duration-200 font-sans">
      
      {/* Top Application Bar */}
      <div className="h-10 shrink-0 flex items-center justify-between px-4 bg-slate-50 dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 select-none">
        <div className="flex items-center gap-4">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700"></div>
          </div>
          <div className="text-[10px] font-bold text-slate-500 dark:text-zinc-400 uppercase tracking-widest flex items-center gap-2">
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            Lite Obsidian Vault / My-Knowledge-Base
          </div>
        </div>
        <div className="flex gap-4">
          <div className="text-[10px] text-slate-400 dark:text-zinc-500 font-mono uppercase tracking-wider">
            Connected: Local Session
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden w-full h-full">
        {/* SIDEBAR */}
        <Sidebar
          notes={notes}
          currentNoteId={currentNoteId}
          onSelectNote={handleSelectNote}
          onCreateNote={handleCreateNote}
          onDeleteNote={handleDeleteNote}
          onExportHtml={handleExportHtml}
          darkMode={darkMode}
          onToggleTheme={handleToggleTheme}
        />

        {/* WORKSPACE AREA */}
        <div className="flex-1 flex flex-col overflow-hidden h-full bg-white dark:bg-zinc-900">
          
          {/* Workspace Mode Selection (Editor vs Graph Map view) */}
          <div className="bg-slate-50 dark:bg-zinc-900 border-b border-slate-200 dark:border-zinc-800 px-6 py-2 flex items-center justify-between shrink-0 select-none">
            <div className="flex items-center space-x-1 bg-slate-200/60 dark:bg-zinc-800 p-0.5 rounded">
              <button
                onClick={() => setWorkspaceTab("editor")}
                className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition-all cursor-pointer ${
                  workspaceTab === "editor"
                    ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white"
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Edit & Preview</span>
              </button>
              <button
                onClick={() => setWorkspaceTab("graph")}
                className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition-all cursor-pointer ${
                  workspaceTab === "graph"
                    ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-white"
                }`}
              >
                <Map className="w-3.5 h-3.5" />
                <span>Graph View</span>
              </button>
            </div>

            <div className="text-[10px] font-bold text-slate-400 dark:text-zinc-500 uppercase tracking-widest hidden sm:block">
              Vault Index: {notes.length} notes
            </div>
          </div>

          {/* WORKSPACE TAB RENDERING */}
          <div className="flex-1 overflow-hidden relative">
            {workspaceTab === "editor" ? (
              currentNote ? (
                <Editor
                  note={currentNote}
                  notes={notes}
                  onUpdateNote={handleUpdateNote}
                  onSelectNote={handleSelectNote}
                  onWikilinkClick={handleWikilinkClick}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center space-y-4 p-8 text-center bg-slate-50 dark:bg-zinc-950">
                  <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 rounded text-indigo-600 dark:text-indigo-400 shadow-sm animate-pulse">
                    <FileText className="w-10 h-10" />
                  </div>
                  <div className="max-w-md">
                    <h3 className="text-sm font-bold text-slate-800 dark:text-zinc-200 uppercase tracking-wider">No active note selected</h3>
                    <p className="text-xs text-slate-400 dark:text-zinc-500 mt-1">
                      Select an existing note from the sidebar or click the "New Note" button to start mapping your second brain.
                    </p>
                  </div>
                  <button
                    onClick={() => handleCreateNote()}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs px-4 py-2 rounded shadow-sm transition-all cursor-pointer"
                  >
                    Create a Note
                  </button>
                </div>
              )
            ) : (
              <GraphView
                notes={notes}
                currentNoteId={currentNoteId}
                onSelectNote={handleSelectNote}
              />
            )}
          </div>

        </div>
      </div>

      {/* Status Bar */}
      <div className="h-6 shrink-0 bg-slate-100 dark:bg-zinc-900 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between px-3 text-[10px] text-slate-500 dark:text-zinc-400 font-medium select-none">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
            CONNECTED: LOCAL-DISK
          </div>
          <div className="opacity-50">UTF-8</div>
        </div>
        <div className="flex items-center gap-4">
          <div>{wordCount} WORDS</div>
          <div>{charCount} CHARACTERS</div>
          <div className="text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider">Markdown</div>
        </div>
      </div>

    </div>
  );
}
